# Entrega para o Works — Leon Coletivo

1. Leia `LEON_COLETIVO_MASTER_WORKS.md`: especificação, fases LC-00 a LC-05 e 28 testes de aceitação.
2. Consulte `LEON_COLETIVO_FONTES.md`: arquivos examinados, snapshot e limites da inspeção.
3. Use `LEON_COLETIVO_PROMPT_INICIAL.txt` como mensagem de abertura no Works, junto aos documentos.

O primeiro resultado esperado é **LC-00 + LC-01**, não todas as fases em uma alteração enorme. O perfil atual deve continuar funcionando. Este pacote não contém código aplicado, alterações no GitHub ou testes executados; orienta o agente de desenvolvimento a implementar no checkout real com evidência.

Data: 06/09/2026 · Versão: 1.0.
