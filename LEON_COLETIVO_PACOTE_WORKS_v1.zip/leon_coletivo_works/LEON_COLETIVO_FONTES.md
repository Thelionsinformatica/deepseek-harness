# LEON COLETIVO — Fontes e limites da inspeção

**Data da preparação:** 06/09/2026.  
**Base:** `Thelionsinformatica/deepseek-harness`, branch `leon/identity-pt-br`, commit `529df9719f80da06c561d942310b8582c692ac67`.

Este inventário permite ao Works reabrir os mesmos arquivos e confrontar o documento mestre com o checkout atual. As leituras foram realizadas pela integração GitHub. Não houve alteração do repositório, instalação de modelos ou execução de testes nesta preparação. Acesso remoto de leitura não comprova o estado do computador do usuário.

O commit fixa a versão analisada; não é uma ordem para retroceder um checkout mais novo. A branch local, alterações não commitadas, overlays de configuração, modelos instalados, GPU e home efetivamente usados continuam sujeitos a verificação.

## Repositório

Para arquivos `R02` a `R14`, o endereço de inspeção é a base abaixo seguida do caminho da tabela:

```text
https://github.com/Thelionsinformatica/deepseek-harness/blob/529df9719f80da06c561d942310b8582c692ac67/
```

| ID | Caminho/fonte | Evidência utilizada |
|---|---|---|
| R01 | Consulta à coleção de branches do repositório | Branch e SHA remoto observados. |
| R02 | `AGENTS.md` | Plugins, regras de alteração, logs, qualidade, comandos e instruções de testes. |
| R03 | `docs/architecture.md` | Serviços Cordis, composição, eventos, sessão e separação host/agente. |
| R04 | `packages/experimental/AGENTS.md` | Pacotes privados, prefixo e impedimento de dependências de runtime em release. |
| R05 | `packages/experimental/agent-team/README.md` | Persistência, revisão de tarefas, mailbox, limites, flat roster e limitações. |
| R06 | `packages/experimental/agent-team/src/index.ts` | Fachada real de serviços de criação, mensagens, quadro e ciclo de vida. |
| R07 | `packages/experimental/tool-agent-team/src/index.ts` | Política opt-in, schemas e diferença quiet/wakeup no commit examinado; trecho inicial até aproximadamente a linha 210, complementado pelo README do pacote lido na conversa. |
| R08 | `packages/subagent/subagent-spawn-in-process/README.md` | Contexto novo, herança, capacidades e comportamento de spawn. |
| R09 | `packages/bundle/base/cordis.patch.yml`, linhas 1–245; `packages/bundle/base/README.md` | Modelos, adapter, armazenamento, precedência integral de patches e gateway local externo. |
| R10 | `apps/cli/config/agent-presets/leon/agent.cordis.yml` | Auditor, memória, separação host/preset e ferramentas de delegação. Trechos pertinentes foram examinados, não uma execução da composição. |
| R11 | `.agents/notes/implemented/feature/2026-08-25-controlled-reviewed-memory-write.md` | Contrato documentado de revisão humana e gravação controlada; precisa ser confrontado com implementação e configuração atuais. |
| R12 | `.agents/notes/implemented/feature/2026-08-26-structured-procedure-learning.md` | Contrato documentado de procedimentos: origem de evidência, mesma sessão, revisão humana, validade e reutilização. |
| R13 | `package.json`, trecho inicial | Node/pnpm, scripts de testes, build, aceitação e gates. |
| R14 | `.agents/notes/implemented/architecture/2026-08-22-leon-local-first-model-routing.md` | História/decisões de roteamento; há divergências com R09 sobre a cadeia externa, portanto não é fonte isolada para reproduzir a configuração atual. |

R01:

```text
https://api.github.com/repos/Thelionsinformatica/deepseek-harness/branches?per_page=100
```

Outros documentos já identificados como relevantes para a implementação: `packages/AGENTS.md`, `docs/AGENTS.md`, `docs/testing.md`, `docs/defensive-patterns.md`, `examples/AGENTS.md`, `docs/subsystems/agent-team.md`, a nota de incubação experimental de 18/08/2026 e os testes dos pacotes envolvidos. O Works deve lê-los quando aplicáveis; essa indicação não significa que todo arquivo/teste do repositório tenha sido auditado.

## Documentação primária externa

| ID | Fonte | Uso restrito nesta especificação |
|---|---|---|
| W01 | Catálogo oficial Ollama: Qwen3.5 4B | Tag e tamanho publicado aproximado de 3,4 GB. |
| W02 | Ollama: Tool calling | Necessidade de ciclo de chamadas e resultados de ferramentas, incluindo streaming. |
| W03 | Ollama: OpenAI compatibility | Compatibilidade parcial; validar o adapter real e seus parâmetros. |
| W04 | Catálogo oficial Ollama: Ministral 3 3B | Candidato opcional para comparação posterior. |
| W05 | Ollama: FAQ | Concorrência, memória, contexto e observação de carregamento. |

```text
W01 https://ollama.com/library/qwen3.5:4b
W02 https://docs.ollama.com/capabilities/tool-calling
W03 https://docs.ollama.com/api/openai-compatibility
W04 https://ollama.com/library/ministral-3:3b
W05 https://docs.ollama.com/faq
```

Não foram utilizados rankings como prova de desempenho do coletivo. O pacote não reproduz, afirma nem exige equivalência ao modelo do incidente JAN. As dimensões de hardware são informações fornecidas na conversa, não medições realizadas pelo autor do documento.

## Como tratar divergências

Código executável e composição resolvida precisam ser confrontados com as regras e o pedido do usuário; não substituir decisões de autorização por exemplos de documentação. Se um recurso estiver presente mas não composto, registrar “implementado, não habilitado”. Se houver apenas um teste em fonte, registrar “teste existente, não executado”. Se uma nota disser “passou”, isso descreve o relato da nota, não o resultado da execução atual.

Todos os nomes novos de missão, estados extras, limites e fases `LC-*` no documento mestre são propostas de implementação. Não apresentá-los como recursos nativos já disponíveis.
